package com.banking;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String customerName;
        int accountNumber;
        double initialBalance;
        String accountType;
        int transactionLimit;
        Bank bankObj = new Bank();

        while (true) {
            System.out.println("\nBanking operation");
            System.out.println("1. Create account");
            System.out.println("2. Credit to account");
            System.out.println("3. Withdrawal/debit");
            System.out.println("4. View account details");
            System.out.println("5. Exit");

            int choice = s.nextInt();
            s.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.println("Enter name: ");
                    customerName = s.nextLine();

                    System.out.println("Enter account number: ");
                    accountNumber = s.nextInt();
                    s.nextLine();

                    System.out.println("Enter initial balance: ");
                    initialBalance = s.nextDouble();
                    s.nextLine(); 

                    System.out.println("Enter account type: ");
                    accountType = s.nextLine();

                    CreateAccount acc1;
                    if (accountType.equalsIgnoreCase("savings")) {
                        System.out.println("Enter transaction limit: ");
                        transactionLimit = s.nextInt();
                        s.nextLine(); 
                        acc1 = new CreateSavingsAccount(customerName, accountNumber, initialBalance, transactionLimit, accountType);
                    } else {
                        acc1 = new CreateCurrentAccount(customerName, accountNumber, initialBalance, accountType);
                    }

                    bankObj.addCustomer(acc1);
                    acc1.displayAccountDetails();
                    break;

                case 2:
                    System.out.println("Enter account number to credit amount: ");
                    accountNumber = s.nextInt();
                    System.out.println("Enter amount to credit: ");
                    double creditAmount = s.nextDouble();
                    CreateAccount account = bankObj.getCustomer(accountNumber);

                    if (account != null) {
                        account.creditToAccount(creditAmount);
                    } else {
                        System.out.println("Account not found.");
                    }
                    break;

                case 3:
                    System.out.println("Enter account number to debit from: ");
                    accountNumber = s.nextInt();
                    System.out.println("Enter amount to debit: ");
                    double debitAmount = s.nextDouble();
                    CreateAccount account1 = bankObj.getCustomer(accountNumber);

                    if (account1 != null) {
                        account1.debitFromAccount(debitAmount);
                    } else {
                        System.out.println("Account not found.");
                    }
                    break;

                case 4:
                    System.out.println("Enter account number to view details: ");
                    accountNumber = s.nextInt();
                    CreateAccount accountHolder = bankObj.getCustomer(accountNumber);

                    if (accountHolder != null) {
                        accountHolder.displayAccountDetails();
                    } else {
                        System.out.println("Account not found.");
                    }
                    break;

                case 5:
                    System.out.println("Exiting the program. Thank you!");
                    s.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}
