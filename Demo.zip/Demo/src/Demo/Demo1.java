package Demo;/*
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Demo1 {

	public static void main(String[] args) {

		String url = "jdbc:mysql://localhost:3306/jdbc"; 
		        String username = "root"; 
		        String password = "sri89730"; 
		        String query = "CREATE TABLE IF NOT EXISTS users ("
		                     + "id INT AUTO_INCREMENT PRIMARY KEY, "
		                     + "name VARCHAR(100), "
		                     + "email VARCHAR(100)"
		                     + ")";
		        try (Connection connection = DriverManager.getConnection(url, username, password);
		             Statement statement = connection.createStatement()) {
		            statement.executeUpdate(query);
		            System.out.println("Table created or already exists.");
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
		    }

}/*
import java.sql.*;
import java.util.Scanner;

public class Demo1 {
    
    private static final String URL = "jdbc:mysql://localhost:3306/jd"; 
    private static final String USER = "root";  
    private static final String PASSWORD = "sri89730";
    public static Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static void createTable() {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS users ("
                                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                                + "name VARCHAR(100), "
                                + "email VARCHAR(100)"
                                + ")";
        
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(createTableSQL);
            System.out.println("Table created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void insertData(String name, String email) {
        String insertSQL = "INSERT INTO users (name, email) VALUES (?, ?)";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.executeUpdate();
            System.out.println("Data inserted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void retrieveData() {
        String selectSQL = "SELECT * FROM users";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(selectSQL);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void userdata() {
        String sql = "SELECT name FROM users";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                String name = rs.getString("name");
                System.out.println("Name: " + name);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void updateData(int userId, String newEmail) {
        String updateSQL = "UPDATE users SET email = ? WHERE id = ?";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {
            pstmt.setString(1, newEmail);
            pstmt.setInt(2, userId);
            pstmt.executeUpdate();
            System.out.println("Data updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void deleteData(int userId) {
        String deleteSQL = "DELETE FROM users WHERE id = ?";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
            System.out.println("Data deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("\n----- Menu -----");
            System.out.println("1. Create Table");
            System.out.println("2. Insert Data");
            System.out.println("3. Retrieve Data");
            System.out.println("4. Update Data");
            System.out.println("5. Delete Data");
            System.out.println("6. Show Usernames");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    createTable();
                    break;
                case 2:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    insertData(name, email);
                    break;
                case 3:
                    retrieveData();
                    break;
                case 4:
                    System.out.print("Enter user ID to update: ");
                    int userIdToUpdate = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new email: ");
                    String newEmail = scanner.nextLine();
                    updateData(userIdToUpdate, newEmail);
                    break;
                case 5:
                    System.out.print("Enter user ID to delete: ");
                    int userIdToDelete = scanner.nextInt();
                    deleteData(userIdToDelete);
                    break;
                case 6:
                    userdata();
                    break;
                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return; 
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
}*/
import java.sql.*;
import java.util.*;

public class Demo1 {
    
    private static final String URL = "jdbc:mysql://localhost:3306/banking"; 
    private static final String USER = "root";  
    private static final String PASSWORD = "sri89730"; 
    public static Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static void createTables() {
        String createCustomerTableSQL = "CREATE TABLE IF NOT EXISTS customers ("
                                       + "id INT AUTO_INCREMENT PRIMARY KEY, "
                                       + "name VARCHAR(100), "
                                       + "email VARCHAR(100) UNIQUE NOT NULL"
                                       + ")";
                                       
        String createAccountTableSQL = "CREATE TABLE IF NOT EXISTS accounts ("
                                      + "id INT AUTO_INCREMENT PRIMARY KEY, "
                                      + "customer_id INT, "
                                      + "account_number VARCHAR(20) UNIQUE NOT NULL, "
                                      + "balance DECIMAL(10, 2) DEFAULT 0.0, "
                                      + "FOREIGN KEY (customer_id) REFERENCES customers(id)"
                                      + ")";

        String createTransactionTableSQL = "CREATE TABLE IF NOT EXISTS transactions ("
                                          + "id INT AUTO_INCREMENT PRIMARY KEY, "
                                          + "account_id INT, "
                                          + "transaction_type VARCHAR(10), "
                                          + "amount DECIMAL(10, 2), "
                                          + "transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
                                          + "FOREIGN KEY (account_id) REFERENCES accounts(id)"
                                          + ")";
        
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(createCustomerTableSQL);
            stmt.executeUpdate(createAccountTableSQL);
            stmt.executeUpdate(createTransactionTableSQL);
            System.out.println("Tables created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void insertCustomer(String name, String email) {
        if (!isValidEmail(email)) {
            System.out.println("Invalid email format. Please try again.");
            return;
        }
        
        String insertSQL = "INSERT INTO customers (name, email) VALUES (?, ?)";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.executeUpdate();
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void createAccount(int customerId, String accountNumber) {
        if (!isValidAccountNumber(accountNumber)) {
            System.out.println("Invalid account number format. Please try again.");
            return;
        }

        String insertSQL = "INSERT INTO accounts (customer_id, account_number) VALUES (?, ?)";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
            pstmt.setInt(1, customerId);
            pstmt.setString(2, accountNumber);
            pstmt.executeUpdate();
            System.out.println("Account created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void recordTransaction(int accountId, String transactionType, double amount) {
        if (amount <= 0) {
            System.out.println("Amount must be greater than zero.");
            return;
        }

        String updateAccountSQL = "UPDATE accounts SET balance = balance + ? WHERE id = ?";
        String insertTransactionSQL = "INSERT INTO transactions (account_id, transaction_type, amount) VALUES (?, ?, ?)";

        try (Connection conn = connect();
             PreparedStatement pstmtUpdate = conn.prepareStatement(updateAccountSQL);
             PreparedStatement pstmtInsert = conn.prepareStatement(insertTransactionSQL)) {
            if (transactionType.equalsIgnoreCase("deposit")) {
                pstmtUpdate.setDouble(1, amount);
            } else if (transactionType.equalsIgnoreCase("withdraw")) {
                pstmtUpdate.setDouble(1, -amount);
            }
            pstmtUpdate.setInt(2, accountId);
            pstmtUpdate.executeUpdate();
            pstmtInsert.setInt(1, accountId);
            pstmtInsert.setString(2, transactionType);
            pstmtInsert.setDouble(3, amount);
            pstmtInsert.executeUpdate();

            System.out.println("Transaction recorded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void displayCustomers() {
        String selectSQL = "SELECT * FROM customers";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(selectSQL)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void displayAccounts() {
        String selectSQL = "SELECT * FROM accounts";
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(selectSQL)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                int customerId = rs.getInt("customer_id");
                String accountNumber = rs.getString("account_number");
                double balance = rs.getDouble("balance");
                System.out.println("ID: " + id + ", Customer ID: " + customerId + ", Account Number: " + accountNumber + ", Balance: " + balance);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        boolean isValid = pattern.matcher(email).matches();
        System.out.println("Testing email: " + email);
        System.out.println("Is valid: " + isValid);
        return isValid;
    }
    public static boolean isValidAccountNumber(String accountNumber) {
        return accountNumber.matches("^[a-zA-Z0-9]{10,20}$");
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        createTables();

        while (true) {
            System.out.println("\n----- Banking Menu -----");
            System.out.println("1. Add Customer");
            System.out.println("2. Create Account");
            System.out.println("3. Record Transaction");
            System.out.println("4. Display Customers");
            System.out.println("5. Display Accounts");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter customer name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter customer email: ");
                    String email = scanner.nextLine();
                    insertCustomer(name, email);
                    break;
                case 2:
                    System.out.print("Enter customer ID to create account: ");
                    int customerId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter account number: ");
                    String accountNumber = scanner.nextLine();
                    createAccount(customerId, accountNumber);
                    break;
                case 3:
                    System.out.print("Enter account ID: ");
                    int accountIdForTransaction = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter transaction type (deposit/withdraw): ");
                    String transactionType = scanner.nextLine();
                    System.out.print("Enter amount: ");
                    double amount = scanner.nextDouble();
                    recordTransaction(accountIdForTransaction, transactionType, amount);
                    break;
                case 4:
                    displayCustomers();
                    break;
                case 5:
                    displayAccounts();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
}

